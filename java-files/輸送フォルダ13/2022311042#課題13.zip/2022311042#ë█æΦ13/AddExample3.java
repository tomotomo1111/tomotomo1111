import java.io.*;

public class AddExample3{
	public static void main(String[] args) throws IOException{
		String fileName = "JavaFile2.txt";
		BufferedReader reader = new BufferedReader(new FileReader(fileName));
		int i=0;
		String line;
		String[] array = new String[50];
		while ((line = reader.readLine()) != null) {
			array[i] = line;
			i++;
		}
		reader.close();
		array[i] = "�ȉ����l�f�[�^�ƂȂ�܂��D";
		PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(fileName)));
		for(int x=i; x>=0; x--) {
			writer.println(array[x]);
		}
		writer.close();
	}
}